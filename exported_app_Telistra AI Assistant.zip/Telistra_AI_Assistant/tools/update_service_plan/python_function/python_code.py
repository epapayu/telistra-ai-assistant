import datetime
from typing import Any

def update_service_plan(new_plan_id: str) -> dict[str, Any]:
    """
    Applies a requested plan upgrade or change to the customer account.

    Args:
        new_plan_id (str): The ID of the new plan to apply (e.g., "plan_essential_180gb").

    Returns:
        dict[str, Any]: A dictionary indicating the status of the update,
                        account ID, new plan ID, effective date, confirmation number,
                        and a success message.
    """
    # MOCK: Placeholder for updating a customer's service plan.
    # This mock simulates a successful plan update.
    # In a real scenario, this would interact with a customer account management system.
    account_id = context.state.get("account_id", "user_123") # Default for demo

    if not account_id:
        return {"status": "FAILED", "error": True, "message": "Account ID not found in context. Cannot update service plan."}

    # MOCK: Simulate different plan IDs
    if new_plan_id == "plan_essential_180gb":
        new_plan_name = "Essential Mobile Plan 180GB"
    elif new_plan_id == "plan_basic_40gb":
        new_plan_name = "Basic Mobile Plan 40GB"
    else:
        return {"status": "FAILED", "error": True, "message": f"Invalid new_plan_id: '{new_plan_id}'. Please provide a valid plan ID."}

    return {
        "status": "SUCCESS",
        "account_id": account_id,
        "new_plan_id": new_plan_id,
        "new_plan_name": new_plan_name,
        "effective_date": "IMMEDIATE",
        "confirmation_number": "CFM-TLS-33019",
        "message": "Service plan successfully updated."
    }