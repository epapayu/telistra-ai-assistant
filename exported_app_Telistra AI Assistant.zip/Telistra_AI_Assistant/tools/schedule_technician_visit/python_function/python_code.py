import datetime
from typing import Any, Optional

def schedule_technician_visit(preferred_date: Optional[str] = None, time_slot: str = "Any") -> dict[str, Any]:
    """
    Schedules an on-site Telstra field technician for physical hardware/line repair.

    Args:
        preferred_date (Optional[str]): The preferred date for the visit in YYYY-MM-DD format.
                                        If not provided, defaults to today's date from context.
        time_slot (str): The preferred time slot for the visit (e.g., "Morning", "Afternoon", "Any").

    Returns:
        dict[str, Any]: A dictionary indicating the status of the scheduling,
                        booking reference, service ID, appointment date, time slot,
                        and technician notes.
    """
    # MOCK: Placeholder for scheduling a technician visit.
    # This mock simulates a successful booking.
    # In a real scenario, this would interact with a scheduling system.
    service_id = context.state.get("service_id", "service_456") # Default for demo
    current_date_str = context.state.get("current_date", datetime.date.today().strftime("%Y-%m-%d"))

    if not service_id:
        return {"status": "FAILED", "error": True, "message": "Service ID not found in context. Cannot schedule technician."}

    appointment_date_obj: datetime.date
    if preferred_date:
        try:
            appointment_date_obj = datetime.datetime.strptime(preferred_date, "%Y-%m-%d").date()
        except ValueError:
            return {"status": "FAILED", "error": True, "message": "Invalid date format for preferred_date. Please use YYYY-MM-DD."}
    else:
        # Use current date from context if preferred_date is not provided
        appointment_date_obj = datetime.datetime.strptime(current_date_str, "%Y-%m-%d").date()

    # MOCK: Simple validation for time_slot
    valid_time_slots = ["Morning", "Afternoon", "Any"]
    if time_slot not in valid_time_slots:
        return {"status": "FAILED", "error": True, "message": f"Invalid time slot '{time_slot}'. Please choose from {', '.join(valid_time_slots)}."}

    return {
        "status": "CONFIRMED",
        "booking_reference": "TECH-TLS-88301",
        "service_id": service_id,
        "appointment_date": appointment_date_obj.strftime("%Y-%m-%d"),
        "time_slot": time_slot,
        "technician_notes": "NBN line degradation inspection."
    }