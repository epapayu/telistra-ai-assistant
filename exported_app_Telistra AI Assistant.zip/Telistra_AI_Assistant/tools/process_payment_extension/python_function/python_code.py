import datetime
from typing import Any

def process_payment_extension(extension_days: int = 14) -> dict[str, Any]:
    """
    Processes a payment extension request for an eligible Telstra customer account.

    Args:
        extension_days (int): The number of days to extend the payment due date. Defaults to 14 days.

    Returns:
        dict[str, Any]: A dictionary indicating the status of the extension,
                        the account ID, original and new due dates, a confirmation code,
                        and a message.
    """
    # MOCK: Placeholder for processing a payment extension.
    # This mock simulates a successful payment extension.
    # In a real scenario, this would interact with a billing or payment system.
    account_id = context.state.get("account_id", "user_123") # Default for demo

    if not account_id:
        return {"status": "FAILED", "error": True, "message": "Account ID not found in context. Cannot process payment extension."}

    # MOCK: Assume a fixed original due date for demonstration
    original_due_date_str = "2026-08-14"
    try:
        original_due_date = datetime.datetime.strptime(original_due_date_str, "%Y-%m-%d").date()
        new_due_date = original_due_date + datetime.timedelta(days=extension_days)
    except ValueError:
        return {"status": "FAILED", "error": True, "message": "Internal error: Could not parse original due date."}

    return {
        "status": "SUCCESS",
        "account_id": account_id,
        "original_due_date": original_due_date_str,
        "new_due_date": new_due_date.strftime("%Y-%m-%d"),
        "confirmation_code": "EXT-TLS-99281",
        "message": f"Payment extension granted for {extension_days} days."
    }