import datetime
from typing import Any

def handoff_to_human(reason: str) -> dict[str, Any]:
    """
    Escalates the conversation state to a live agent queue.

    Args:
        reason (str): The reason for the handoff (e.g., "unresolvable request", "explicit human agent request").

    Returns:
        dict[str, Any]: A dictionary indicating the status of the handoff,
                        the queue name, estimated wait time, and whether the transcript
                        was forwarded.
    """
    # MOCK: Placeholder for initiating a human agent handoff.
    # This mock simulates a successful handoff initiation.
    # In a real scenario, this would interact with a CRM or contact center system.
    account_id = context.state.get("account_id", "user_123") # Default for demo

    if not account_id:
        # Even if account_id is missing, we can still attempt a handoff, but note it.
        print("Warning: Account ID not found in context during human handoff.")

    return {
        "status": "HANDOFF_INITIATED",
        "queue_name": "Telstra_Customer_Care_L2",
        "estimated_wait_time_minutes": 2,
        "transcript_forwarded": True,
        "handoff_reason": reason
    }